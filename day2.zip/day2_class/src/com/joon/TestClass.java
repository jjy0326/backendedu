package com.joon;

public class TestClass {
    String name;
    String firstDay;
    String FinalDay;
    int visit;
    String gender;
    String age;
	public TestClass(String str) {
		this.setmember(str);
	}
	public void setmember(String str) {
		String[] split= str.split(",");			
		   this.name= split[0];
		   this.firstDay=split[1];
		   this.FinalDay=split[2];
		   this.visit=Integer.parseInt(split[3]);
		   this.gender=split[4];
		   this.age=split[5];
		
	}

}
